/** Automatically generated file. DO NOT MODIFY */
package com.apigee.appservices.android_template;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}