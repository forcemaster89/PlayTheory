Welcome to the Apigee App Services template app for Android!

App Services is Apigee’s hosted version of the open-source technology “Usergrid” — you may find references to that name in a few places. 

Import this project in Eclipse / Android Developer Tools to get started.
1. Open ADT, do File > Import
2. Under “Android”, select “Existing Android Code Into Workspace”, and click Next
3. Pick the folder containing this README file as the root directory
4. Eclipse should find an application called appservices-android-template automatically. Just click Finish!

You will need to make a few edits for this template to work. Follow the instructions in src/com/apigee/appservices/android_template/MainActivity.java

If you followed the steps correctly, you should see a visual confirmation when you run the app!