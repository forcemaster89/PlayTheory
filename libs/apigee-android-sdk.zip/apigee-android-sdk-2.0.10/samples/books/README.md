##Simple books android app.

Beginnings of class application for Android.
