/** Automatically generated file. DO NOT MODIFY */
package com.apigee.monitoringsample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}